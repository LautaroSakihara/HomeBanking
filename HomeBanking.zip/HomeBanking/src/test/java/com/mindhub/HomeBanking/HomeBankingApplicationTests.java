package com.mindhub.HomeBanking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HomeBankingApplicationTests {

	@Test
	void contextLoads() {
	}

}
